/*
 * recoil-stdio.h - stdio subclass of RECOIL
 *
 * Copyright (C) 2015-2021  Piotr Fusik
 *
 * This file is part of RECOIL (Retro Computer Image Library),
 * see http://recoil.sourceforge.net
 *
 * RECOIL is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 *
 * RECOIL is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with RECOIL; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef _RECOILSTDIO_H_
#define _RECOILSTDIO_H_

#include <stdbool.h>

#include "recoil.h"

#ifdef __cplusplus
extern "C" {
#endif

RECOIL *RECOILStdio_New(void);
bool RECOILStdio_Load(RECOIL *self, const char *filename);

#ifdef __cplusplus
}
#endif

#endif
